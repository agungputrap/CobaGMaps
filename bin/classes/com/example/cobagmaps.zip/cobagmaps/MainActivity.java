package com.example.cobagmaps;


import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.http.util.LangUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;

import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements LocationListener {
	
	  private LocationManager locationManager;
	  private String provider;
	  EditText s ;
	  EditText d;
	  LatLng src;
	  LatLng dest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // Get the location manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
       
        // Define the criteria how to select the locatioin provider -> use
        // default
        Criteria criteria = new Criteria();
        provider = locationManager.getBestProvider(criteria, false);
        Location location = locationManager.getLastKnownLocation(provider);
        
        // Initialize the location fields
        if (location != null) {
          System.out.println("Provider " + provider + " has been selected.");
          onLocationChanged(location);
       
        } else {
            Toast.makeText(this, "belum terpilih" + provider,
                    Toast.LENGTH_SHORT).show();
          }
        s = (EditText) findViewById(R.id.src);
        src = getLatLongFromGivenAddress (s.getText().toString());
        d = (EditText) findViewById(R.id.dest);
        dest = getLatLongFromGivenAddress (d.getText().toString());
        Button search = (Button) findViewById(R.id.Search);
 
        // button click event untuk simpan penambahan data
        search.setOnClickListener(new View.OnClickListener() {
 
            @Override
            public void onClick(View view) {
            	if(s.getText().toString().trim().length()>0 && d.getText().toString().trim().length()>0){
            		getRoute(src,dest);
            	}else{
             	   Toast.makeText(getBaseContext(), "silahkan isi asal dan tujuan", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        
      }
    public  LatLng getLatLongFromGivenAddress(String strAddress)
    {
    Geocoder coder = new Geocoder(this);
    List<Address> address;
    Address location = null;
        try {
			address = coder.getFromLocationName(strAddress,5);
			if (address == null) {
	            return null;
	        }
	        location = address.get(0);
	       
	        
		} catch (IOException e) {
			e.printStackTrace();
		} 
        return new LatLng(location.getLatitude(), location.getLongitude());

    }
    

    public void getRoute (LatLng sourcePosition, LatLng destPosition){
    	Direction md = new Direction();
        MapFragment mapFrag = (MapFragment) getFragmentManager()
                .findFragmentById(R.id.map);
        GoogleMap mMap = mapFrag.getMap();
        Document doc = md.getDocument(sourcePosition, destPosition, Direction.MODE_DRIVING);

        ArrayList<LatLng> directionPoint = md.getDirection(doc);
                    PolylineOptions rectLine = new PolylineOptions().width(3).color(
                            Color.RED);

                    for (int i = 0; i < directionPoint.size(); i++) {
                        rectLine.add(directionPoint.get(i));
                    }
                  mMap.addPolyline(rectLine);
                    
    }
    
	@Override
	public void onLocationChanged(Location arg0) {
		Toast.makeText(this, "provider" + "\n"+arg0.getTime()+"\n"+arg0.getLatitude()+"\n"+arg0.getLongitude()+"\n"+arg0.getSpeed(),
		          Toast.LENGTH_SHORT).show();
        try {
            DefaultHttpClient client = new DefaultHttpClient();  
            String postURL ="http://10.0.2.2/cobaMaps/data.php";
            HttpPost post = new HttpPost(postURL);
                List<NameValuePair> params = new ArrayList<NameValuePair>();
               params.add(new BasicNameValuePair("lat",""+arg0.getLatitude()));   	   
               params.add(new BasicNameValuePair("long", ""+arg0.getLongitude()));   
               params.add(new BasicNameValuePair("speed", ""+arg0.getSpeed()));
               params.add(new BasicNameValuePair("time", ""+arg0.getTime()));
               UrlEncodedFormEntity ent = new UrlEncodedFormEntity(params,HTTP.UTF_8);
               post.setEntity(ent);
               HttpResponse responsePOST = client.execute(post);  
               HttpEntity resEntity = responsePOST.getEntity();  
               if (resEntity != null) {    
                   Log.i("RESPONSE",EntityUtils.toString(resEntity));
               }
               
               
               
        } catch (Exception e) {
            e.printStackTrace();
        }
		
	}

//      /* Request updates at startup */
      @Override
      protected void onResume() {
        super.onResume();
        locationManager.requestLocationUpdates(provider, 400, 1, (android.location.LocationListener) this);
      }
//
//      /* Remove the locationlistener updates when Activity is paused */
      @Override
      protected void onPause() {
        super.onPause();
        locationManager.removeUpdates((android.location.LocationListener) this);
      }
//
     
//
      public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub

      }
//
      public void onProviderEnabled(String provider) {
        Toast.makeText(this, "Enabled new provider " + provider,
            Toast.LENGTH_SHORT).show();

      }
//
      public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Disabled provider " + provider,
            Toast.LENGTH_SHORT).show();
      }
   
    }
